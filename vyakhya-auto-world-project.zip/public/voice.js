const statusEl=document.getElementById("status");
document.getElementById("speak").addEventListener("click",()=>{
  if(!("speechSynthesis" in window)){statusEl.textContent="Is browser mein voice support nahi hai.";return;}
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(document.getElementById("msg").value);
  u.lang="hi-IN";
  const voices=speechSynthesis.getVoices();
  const preferred=voices.find(v=>/female|woman|zira|heera/i.test(v.name))||voices.find(v=>v.lang.toLowerCase().startsWith("hi"));
  if(preferred)u.voice=preferred;
  u.onstart=()=>statusEl.textContent="Voice demo chal raha hai…";
  u.onend=()=>statusEl.textContent="Demo complete.";
  speechSynthesis.speak(u);
});
document.getElementById("stop").addEventListener("click",()=>{speechSynthesis.cancel();statusEl.textContent="Stopped.";});
