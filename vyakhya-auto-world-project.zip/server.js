require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcryptjs");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new sqlite3.Database(path.join(dataDir, "vyakhya.db"));

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT)`);
  db.run(`CREATE TABLE IF NOT EXISTS customers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL, model TEXT DEFAULT '', purpose TEXT DEFAULT '', consent INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP)`);
  db.run(`CREATE TABLE IF NOT EXISTS calls (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, outcome TEXT, notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(customer_id) REFERENCES customers(id))`);
  const seed = (username, password, role) => {
    if (!username || !password) return;
    db.get("SELECT id FROM users WHERE username=?", [username], async (err, row) => {
      if (err || row) return;
      const hash = await bcrypt.hash(password, 12);
      db.run("INSERT INTO users(username,password,role) VALUES(?,?,?)", [username, hash, role]);
    });
  };
  seed(process.env.ADMIN_USERNAME || "admin", process.env.ADMIN_PASSWORD || "ChangeThisAdminPassword123!", "admin");
  seed(process.env.STAFF_USERNAME || "staff", process.env.STAFF_PASSWORD || "ChangeThisStaffPassword123!", "staff");
});

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));
app.use(session({
  store: new SQLiteStore({ db: "sessions.db", dir: dataDir }),
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8*60*60*1000 }
}));
app.use((req,res,next)=>{res.locals.user=req.session.user||null;next();});
function auth(req,res,next){ if(!req.session.user) return res.redirect("/login"); next(); }

app.get("/", (req,res)=>res.redirect(req.session.user?"/dashboard":"/login"));
app.get("/login",(req,res)=>res.render("login",{error:""}));
app.post("/login",(req,res)=>{
  db.get("SELECT * FROM users WHERE username=?", [req.body.username], async (err,user)=>{
    if(err || !user || !(await bcrypt.compare(req.body.password||"",user.password)))
      return res.status(401).render("login",{error:"Username ya password galat hai."});
    req.session.user={id:user.id,username:user.username,role:user.role};
    res.redirect("/dashboard");
  });
});
app.post("/logout",auth,(req,res)=>req.session.destroy(()=>res.redirect("/login")));
app.get("/dashboard",auth,(req,res)=>{
  db.get("SELECT COUNT(*) total FROM customers",(e,c)=>db.get("SELECT COUNT(*) total FROM calls",(e2,k)=>res.render("dashboard",{customers:c.total,calls:k.total})));
});
app.get("/customers",auth,(req,res)=>db.all("SELECT * FROM customers ORDER BY id DESC",(e,rows)=>res.render("customers",{rows:rows||[]})));
app.post("/customers",auth,(req,res)=>{
  const {name,phone,model,purpose,consent}=req.body;
  if(!name||!phone) return res.redirect("/customers");
  db.run("INSERT INTO customers(name,phone,model,purpose,consent) VALUES(?,?,?,?,?)",[name.trim(),phone.trim(),model||"",purpose||"",consent==="yes"?1:0],()=>res.redirect("/customers"));
});
app.get("/calls",auth,(req,res)=>db.all(`SELECT calls.*, customers.name, customers.phone FROM calls LEFT JOIN customers ON customers.id=calls.customer_id ORDER BY calls.id DESC`,(e,rows)=>db.all("SELECT id,name,phone,consent FROM customers ORDER BY name",(e2,customers)=>res.render("calls",{rows:rows||[],customers:customers||[]}))));
app.post("/calls",auth,(req,res)=>{
  const {customer_id,outcome,notes}=req.body;
  db.run("INSERT INTO calls(customer_id,outcome,notes) VALUES(?,?,?)",[customer_id||null,outcome||"Not connected",notes||""],()=>res.redirect("/calls"));
});
app.get("/voice-demo",auth,(req,res)=>res.render("voice"));
app.listen(PORT,()=>console.log(`Vyakhya CRM running on port ${PORT}`));
