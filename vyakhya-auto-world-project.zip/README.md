# Vyakhya Auto World AI CRM

A starter customer and call-record CRM with:
- Admin and staff login
- Customer entry
- Call outcome/notes log
- Browser-based Hindi voice demo (not real phone calling)

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Change both passwords and `SESSION_SECRET` to private values.
4. Run `npm install`, then `npm start`.
5. Open `http://localhost:3000`.

## Important
- The starter uses SQLite in the `data/` folder. Some cloud hosts erase local files when an instance restarts/redeploys. Before using it for real customer data, configure persistent storage or migrate to a managed database.
- This demo does not place phone calls, record calls, or connect to a telecom provider.
- Only contact customers when you have the required permission/consent and follow applicable telecom/privacy rules.
- Do not upload `.env`, customer data, passwords, or recordings to GitHub.
